﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Ahorcado
{
    public partial class Form2 : Form

    {

        private int segundos = 0; 
        public Form2()
        {
            InitializeComponent();
            timer1.Interval = 1000; // 1 segundo
            timer1.Tick += timer1_Tick;
            txtTimer.Text = "00:00"; // Inicia en 00:00
            timer1.Start();

          
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
          
        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            segundos++;
            int minutos = segundos / 60;
            int seg = segundos % 60;
            txtTimer.Text = $"{minutos:D2}:{seg:D2}";
        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtTimer_TextChanged(object sender, EventArgs e)
        {

        }

        private void Form2_Load(object sender, EventArgs e)
        {

        }
    }
}
